#!/bin/bash

flameshot gui
